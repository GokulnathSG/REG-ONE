import os
from app.generators.excel_generator import generate_overview_workflow_excel
from app.generators.html_visualization_generator import generate_visualization_html
from app.services import graph_service

REPORTS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "reports")


def overview_excel_path(repo) -> str:
    """The single supported document output: one .xlsx workbook with the
    Session-Mapping and Table-Transformation tabs, built purely from the
    parsed XML/JSON."""
    out = os.path.join(REPORTS_DIR, "Overview_Workflow.xlsx")
    return generate_overview_workflow_excel(repo, out)


def visualization_html_path(repo) -> str:
    """Standalone, self-contained HTML export of the Visualization page:
    Overview graph tab + Table View tab, both still interactive after
    download (no server calls needed). Table View's Mapping Name links also
    open an offline drill-down tab per mapping (its own lineage graph +
    clickable transformation detail), so every mapping's graph is
    pre-rendered here and embedded alongside the overview graph."""
    graph_html = graph_service.overview_graph_html(repo)
    mapping_graphs = {name: graph_service.mapping_graph_html(repo, name) for name in repo.mappings}
    # Minor improvement-2: Mapplets get their own Visual Link/drill-down
    # tab in the downloaded HTML too, same as Mappings.
    mapplet_graphs = {name: graph_service.mapplet_graph_html(repo, name) for name in repo.mapplets}
    out = os.path.join(REPORTS_DIR, "Workflow_Visualization.html")
    return generate_visualization_html(repo, graph_html, mapping_graphs, mapplet_graphs, out)
