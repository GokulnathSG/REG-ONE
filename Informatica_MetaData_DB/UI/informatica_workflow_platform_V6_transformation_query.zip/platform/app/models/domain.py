"""Domain / object model for parsed Informatica PowerCenter workflows.

These classes are intentionally simple, serializable (via to_dict) containers.
They are format-agnostic: both the XML parser and the JSON parser build the
exact same object graph, so everything downstream (analyzer, graph builder,
document/report generators) never needs to know which format the workflow
was uploaded in.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Optional


@dataclass
class Field:
    name: str
    datatype: str = ""
    precision: str = ""
    scale: str = ""
    port_type: str = ""  # for transformation ports: INPUT / OUTPUT / INPUT/OUTPUT / VARIABLE

    def to_dict(self):
        return {"name": self.name, "datatype": self.datatype, "precision": self.precision,
                "scale": self.scale, "port_type": self.port_type}


@dataclass
class Table:
    name: str
    kind: str  # SOURCE | TARGET
    connection: str = ""
    database: str = ""
    schema: str = ""
    fields: List[Field] = field(default_factory=list)

    def to_dict(self):
        return {"name": self.name, "kind": self.kind, "connection": self.connection,
                "database": self.database, "schema": self.schema,
                "fields": [f.to_dict() for f in self.fields]}


@dataclass
class Transformation:
    name: str
    type: str = ""
    reusable: bool = False
    input_ports: List[Field] = field(default_factory=list)
    output_ports: List[Field] = field(default_factory=list)
    variable_ports: List[Field] = field(default_factory=list)
    expressions: List[Dict] = field(default_factory=list)     # [{port, expression}]
    attributes: Dict[str, str] = field(default_factory=dict)  # TABLEATTRIBUTE name->value
    business_logic: str = ""
    implementation_notes: str = ""
    mapping_name: str = ""
    mapplet_name: Optional[str] = None

    def to_dict(self):
        return {
            "name": self.name, "type": self.type, "reusable": self.reusable,
            "input_ports": [p.to_dict() for p in self.input_ports],
            "output_ports": [p.to_dict() for p in self.output_ports],
            "variable_ports": [p.to_dict() for p in self.variable_ports],
            "expressions": self.expressions, "attributes": self.attributes,
            "business_logic": self.business_logic,
            "implementation_notes": self.implementation_notes,
            "mapping_name": self.mapping_name, "mapplet_name": self.mapplet_name,
        }


@dataclass
class Connector:
    from_instance: str
    from_field: str
    to_instance: str
    to_field: str

    def to_dict(self):
        return {"from_instance": self.from_instance, "from_field": self.from_field,
                "to_instance": self.to_instance, "to_field": self.to_field}


@dataclass
class Instance:
    """A single object instance placed inside a Mapping/Mapplet canvas."""
    name: str
    type: str          # SOURCE | TARGET | TRANSFORMATION | MAPPLET
    ref_name: str       # underlying TRANSFORMATION_NAME / SOURCE / TARGET / MAPPLET name
    ref_type: str = ""  # underlying transformation type e.g. 'Expression', 'Source Qualifier'

    def to_dict(self):
        return {"name": self.name, "type": self.type, "ref_name": self.ref_name, "ref_type": self.ref_type}


@dataclass
class Mapplet:
    name: str
    instances: List[Instance] = field(default_factory=list)
    connectors: List[Connector] = field(default_factory=list)
    transformations: List[str] = field(default_factory=list)  # transformation names owned by this mapplet

    def to_dict(self):
        return {"name": self.name, "instances": [i.to_dict() for i in self.instances],
                "connectors": [c.to_dict() for c in self.connectors],
                "transformations": self.transformations}


@dataclass
class Mapping:
    name: str
    instances: List[Instance] = field(default_factory=list)
    connectors: List[Connector] = field(default_factory=list)
    transformations: List[str] = field(default_factory=list)
    mapplets: List[str] = field(default_factory=list)
    sources: List[str] = field(default_factory=list)
    targets: List[str] = field(default_factory=list)

    def to_dict(self):
        return {"name": self.name, "instances": [i.to_dict() for i in self.instances],
                "connectors": [c.to_dict() for c in self.connectors],
                "transformations": self.transformations, "mapplets": self.mapplets,
                "sources": self.sources, "targets": self.targets}


@dataclass
class Session:
    name: str
    mapping_name: str = ""
    reusable: bool = False

    def to_dict(self):
        return {"name": self.name, "mapping_name": self.mapping_name, "reusable": self.reusable}


@dataclass
class WorkflowLink:
    from_task: str
    to_task: str
    condition: str = ""

    def to_dict(self):
        return {"from_task": self.from_task, "to_task": self.to_task, "condition": self.condition}


@dataclass
class TaskInstance:
    name: str
    task_name: str
    task_type: str  # Session | Command | Decision | Start | Email | ...

    def to_dict(self):
        return {"name": self.name, "task_name": self.task_name, "task_type": self.task_type}


@dataclass
class Workflow:
    name: str
    source_file: str = ""
    sessions: Dict[str, Session] = field(default_factory=dict)
    task_instances: List[TaskInstance] = field(default_factory=list)
    links: List[WorkflowLink] = field(default_factory=list)
    execution_order: List[str] = field(default_factory=list)  # ordered TASKINSTANCE names
    warnings: List[str] = field(default_factory=list)

    def to_dict(self):
        return {"name": self.name, "source_file": self.source_file,
                "sessions": {k: v.to_dict() for k, v in self.sessions.items()},
                "task_instances": [t.to_dict() for t in self.task_instances],
                "links": [l.to_dict() for l in self.links],
                "execution_order": self.execution_order,
                "warnings": self.warnings}


@dataclass
class RepositoryModel:
    """Root aggregate returned by any parser: everything extracted from one upload."""
    workflow: Optional[Workflow] = None
    mappings: Dict[str, Mapping] = field(default_factory=dict)
    mapplets: Dict[str, Mapplet] = field(default_factory=dict)
    transformations: Dict[str, Transformation] = field(default_factory=dict)  # key: mapping_name::transform_name
    reusable_transformations: Dict[str, Transformation] = field(default_factory=dict)  # folder-level reusable
    sources: Dict[str, Table] = field(default_factory=dict)
    targets: Dict[str, Table] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)

    def transformation(self, mapping_name: str, transform_name: str) -> Optional[Transformation]:
        t = self.transformations.get(f"{mapping_name}::{transform_name}")
        if t is not None:
            return t
        return self.reusable_transformations.get(transform_name)
