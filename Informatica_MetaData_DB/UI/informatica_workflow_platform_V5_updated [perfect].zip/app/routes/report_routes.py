from flask import Blueprint, render_template, request, jsonify

bp = Blueprint("report", __name__)


@bp.route("/reports")
def reports_page():
    """Informatica ORACLE DB Connector page (previously 'Printable Reports').
    The Overview Workflow Excel and Workflow Visualization HTML downloads
    that used to live here now live under Informatica XML Downloads.

    Minor improvement-1: this page is independent of whether an Informatica
    XML/JSON export has been uploaded yet - the Oracle credentials form
    should always be reachable, so no require_repo() gate here."""
    return render_template("reports.html")


@bp.route("/reports/db-connect", methods=["POST"])
def db_connect():
    """Attempt an Oracle DB connection with the submitted credentials.
    Uses python-oracledb in thin mode (no Oracle client install required)."""
    data = request.get_json(silent=True) or {}
    db_user = (data.get("db_user") or "").strip()
    db_password = data.get("db_password") or ""
    dsn = (data.get("dsn") or "").strip()
    schema = (data.get("schema") or "").strip()

    if not db_user or not db_password or not dsn:
        return jsonify({"ok": False, "message": "DB_USER, DB_PASSWORD and DSN are all required."}), 400

    # Normalize the schema the way the UI displays it: "schema_name."
    schema_qualifier = f"{schema}." if schema and not schema.endswith(".") else schema

    try:
        import oracledb
    except ImportError:
        return jsonify({
            "ok": False,
            "message": "The 'oracledb' driver is not installed on the server. Run "
                       "'pip install oracledb' and try again."
        }), 500

    try:
        connection = oracledb.connect(user=db_user, password=db_password, dsn=dsn)
        connection.close()
    except Exception as exc:  # noqa: BLE001 - surface the driver's own error message
        return jsonify({"ok": False, "message": f"Connection failed: {exc}"}), 400

    return jsonify({
        "ok": True,
        "message": f"Connected to {dsn} as {db_user}"
                   + (f" (schema: {schema_qualifier})" if schema_qualifier else "") + "."
    })
